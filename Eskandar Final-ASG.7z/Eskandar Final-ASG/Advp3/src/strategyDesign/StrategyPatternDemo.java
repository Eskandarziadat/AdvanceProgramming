package strategyDesign;

import java.util.Scanner;

public class StrategyPatternDemo {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		  
		Scanner sc=new Scanner(System.in);
		
		
		System.out.println("Please enter the First number");
		int n1 =sc.nextInt();
		
		System.out.println("Please enter the Second number");
		int n2 =sc.nextInt();
		
		
		
		Context context = new Context(new Operationdevide());		
	      System.out.println("the answer is  " + context.executeStrategy(n1, n2));


	      context = new Context(new OperationMultiply());		
	      System.out.println("the answe is = " + context.executeStrategy(n1, n2));

	}

}