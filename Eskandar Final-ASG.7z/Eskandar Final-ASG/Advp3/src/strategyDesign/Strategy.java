package strategyDesign;


public interface Strategy {
	public int doOperation(int num1, int mum2 );
}
