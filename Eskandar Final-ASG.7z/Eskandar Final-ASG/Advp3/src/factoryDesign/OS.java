package factoryDesign;

public interface OS {

	public void spec();
	
}
