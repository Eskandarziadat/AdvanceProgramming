package factoryDesign;

public class OperatingSystemFactory {

	
	public OS getInstance(String str){
	
		if (str.equals("First one "))
			return new Android();
		else if(str.equals("Second one "))
			return new IOS();
		
		else 
			return new  Windows();
		
		}
	
	
}
