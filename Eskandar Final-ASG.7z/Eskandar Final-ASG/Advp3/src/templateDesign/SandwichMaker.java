package templateDesign;

public class SandwichMaker {

	
	public static void main(String[] args) {
		
		
		Shawerma cust11Shawerma = new ShawermaChicken();
		
		cust11Shawerma.makeShawerma();
		
		Shawerma cust12Shawerma = new ShawermaMeat();
		
		cust12Shawerma.makeShawerma();
		
		
		
	}
}
