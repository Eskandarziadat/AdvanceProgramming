package adapterDesign;

public class TestMainEnemyAttackers{
	
	public static void main(String[] args){
		
		EnemyAircraft rx7craft = new EnemyAircraft();
		
		RobotEnemy E_TheRobot = new RobotEnemy();
		
		E_Attacker robotAdapter = new RobotEnemyAdapter(E_TheRobot);
		
		System.out.println("The Robot");
		
		E_TheRobot.reactToHuman("Eskandar");
		E_TheRobot.flyForward();
		E_TheRobot.smashWithHands();
		System.out.println();
		
		System.out.println("The Enemy Aircraft");
		
		rx7craft.assignDriver("abzakh");
		rx7craft.flyForward();
		rx7craft.fireWeapon();
		System.out.println();
		
		System.out.println("The Robot with Adapter");
		
		robotAdapter.assignDriver("predator");
		robotAdapter.flyForward();
		robotAdapter.fireWeapon();

	}
	
}

