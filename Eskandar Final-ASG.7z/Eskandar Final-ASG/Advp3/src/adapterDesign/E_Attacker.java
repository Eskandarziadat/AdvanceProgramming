package adapterDesign;

public interface E_Attacker {
	
	public void fireWeapon();

	public void flyForward();

	public void assignDriver(String driverName);

}
