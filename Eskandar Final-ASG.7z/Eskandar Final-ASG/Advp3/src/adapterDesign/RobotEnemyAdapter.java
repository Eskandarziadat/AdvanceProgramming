package adapterDesign;


public class RobotEnemyAdapter implements E_Attacker{

	RobotEnemy theRobot;
	
	public RobotEnemyAdapter(RobotEnemy newRobot){
		
		theRobot = newRobot;
		
	}
	
	public void fireWeapon() {
		
		theRobot.smashWithHands();
		
	}

	public void flyForward() {
		
		theRobot.flyForward();
		
	}

	public void assignDriver(String driverName) {
		
		theRobot.reactToHuman(driverName);
		
	}
	
	
	
}
