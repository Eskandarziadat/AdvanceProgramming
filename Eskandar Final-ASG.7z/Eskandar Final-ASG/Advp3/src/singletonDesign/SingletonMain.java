package singletonDesign;

public class SingletonMain {

	
	public static void main(String[] args) {
		
		

//      you cant make a construction		
//		SingletonExample SE1=new SingletonExample();
//		SingletonExample SE2=new SingletonExample();
//		SingletonExample SE3=new SingletonExample();
		
		
		SingletonExample SE= SingletonExample.getInstance();
		SingletonExample SE1= SingletonExample.getInstance();
		SingletonExample SE2= SingletonExample.getInstance();
		
		
		SE.writingToTheFile("Hello as you can see this is a basic Singleton Exmaple  ");
		SE1.writingToTheFile(": write whatever you want , line 2 ");
		SE2.writingToTheFile(": write whatever you want , line 3 ");
		
		
	}
}
