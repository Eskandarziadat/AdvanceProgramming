package singletonDesign;

import java.io.FileWriter;
import java.io.IOException;

public class SingletonExample {
	
  // i created a static variable within the same create a static variable basically from the same type of the class public 

  private static SingletonExample instance = new SingletonExample();
  
 //if any sort of class try to use the instance, it first should get the reference of the static variable 
  
  // method to return the single instance
  public static SingletonExample getInstance(){
      return instance;
   }
  
  
  // i made the constructor private so no one can make a new object, so it can only be accessed within the class
  private SingletonExample(){
	   
  }
  
  public void writingToTheFile(String msg) 
  {
		try (FileWriter fw = new FileWriter("Singletonex.txt",true)) {
			fw.write(msg+"\n");
			System.out.println("your msg is being written " + msg);
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Please contact someone for help ");
		}
	}
  
  

	
}
