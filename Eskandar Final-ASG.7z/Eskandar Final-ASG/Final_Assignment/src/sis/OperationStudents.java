package sis;

import java.util.ArrayList;
import java.util.Scanner;

public class OperationStudents {
	Student student = new Student();
	Scanner scan = new Scanner(System.in);
	ArrayList<Student> stu = new ArrayList<>();
	FileRead fr = FileRead.getInstance();
	Deleteline dl = new Deleteline();
	FindStudent fd = new FindStudent();

	public void studentadd() {
		System.out.print("If you may enter the student ID Please : ");
		student.setId();
		System.out.print("If you may enter the student Name: ");
		student.setName();
		System.out.print("If you may  enter the student Avg: ");
		student.setAvg();

		FileWriterop addstudent = FileWriterop.getInstance();
		addstudent.writefile(student.getId(),student.getName(),student.getAvg());

		System.out.println("====================");
		
		System.out.println("====================");
	}

	public void studentfind() {
		System.out.println("If you may enter the ID that you want to find:");
		String t = scan.nextLine();
		System.out.println("======================");
		
		fd.studentfind(t,"UniStudents.txt"); 
	}

	public void studentdelete() {
		System.out.println("If you may enter the ID that you want to delete:");
		String a = scan.nextLine();
		System.out.println("======================");
		
		dl.filedelete("UniStudents.txt", a, 1,","); 
	}

	public void showstudent() {
		fr.readfile();
	}
}
